
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head> 
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" /> 
        <title>演示：PHP在线生成excel并发送邮件</title>
        <meta name="keywords" content="PHP数据库表excel,phpmailer发送邮件,PHPexcel导出发送" />
        <meta name="description" content="" />
        <link rel="stylesheet" type="text/css" href="http://www.sucaihuo.com/jquery/css/common.css" />

    </head>
    <body>
        <div class="head">
            <div class="head_inner clearfix">
                <ul id="nav">
                    <li><a href="http://www.sucaihuo.com">首 页</a></li>
                    <li><a href="http://www.sucaihuo.com/templates">网站模板</a></li>
                    <li><a href="http://www.sucaihuo.com/js">网页特效</a></li>
                    <li><a href="http://www.sucaihuo.com/php">PHP</a></li>
                    <li><a href="http://www.sucaihuo.com/site">精选网址</a></li>
                </ul>
                <a class="logo" href="http://www.sucaihuo.com"><img src="http://www.sucaihuo.com/Public/images/logo.jpg" alt="素材火logo" /></a>
            </div>
        </div>
        <div class="container">
            <div class="demo">
                <h2 class="title"><a href="http://www.sucaihuo.com/php/870.html">教程：PHP在线生成excel并发送邮件</a></h2>


                邮箱：<input type="text" id="email" class="input" placeholder="请输入邮箱"/>
                <input type="button" value="提交" class="btn" onclick="check()"/>


            </div>
        </div>
        <div class="foot">
            Powered by sucaihuo.com  本站皆为作者原创，转载请注明原文链接：<a href="http://www.sucaihuo.com" target="_blank">www.sucaihuo.com</a>
        </div>
        <script type="text/javascript" src="http://www.sucaihuo.com/Public/js/other/jquery.js"></script> 
        <script type="text/javascript">

                    function check() {
                        var email = $("#email").val();
                        if(email == ''){
                            alert("请输入邮箱");
                            return;
                        }
                        var pattern_email = /^([a-zA-Z0-9_-])+@([a-zA-Z0-9_-])+(.[a-zA-Z0-9_-])+/;
                        if (pattern_email.test(email) != true) {
                            alert("邮箱格式有误！");
                            return;
                        }

                        $.post("ajax.php", {email: email}, function(data) {
                            if (data == '1') {
                                alert("发送成功！");
                            } else {
                                alert(data);
                            }

                        })
                    }
        </script>
    </body>
</html>


<!-- 以下是统计及其他信息，与演示无关，不必理会 -->

<p class="vad">
    <a href="http://www.sucaihuo.com/" target="_blank">sucaihuo.com</a>
    <a href="http://www.sucaihuo.com/js/534.html" target="_blank">说 明</a>
    <a href="http://www.sucaihuo.com/js/534.html" target="_blank">下 载</a>
</p>
<style type="text/css">
    .vad { margin: 10px 0 5px; font-family: Consolas,arial,宋体,sans-serif; text-align:center;}
    .vad a { display: inline-block; height: 36px; line-height: 36px; margin: 0 5px; padding: 0 50px; font-size: 14px; text-align:center; color:#eee; text-decoration: none; background-color: #222;}
    .vad a:hover { color: #fff; background-color: #000;}
    .thead { width: 728px; height: 90px; margin: 0 auto; border-bottom: 40px solid #fff;}
</style>
<div style="width:728px;margin:0 auto">
    <script type="text/javascript">
        /*700*90 创建于 2015-06-27*/
        var cpro_id = "u2176575";
    </script>
    <script src="http://cpro.baidustatic.com/cpro/ui/c.js" type="text/javascript"></script>
</div>
