<?php

function sendExcel($filename, $titles, $data) {
    header("Content-type: text/html; charset=UTF-8");
    if ($filename == '') {
        return "文件名称不能为空！";
    }
    if ($titles == '') {
        return "标题一维数组不能为空！";
    }
    if ($data == '') {
        return "内容二维数组不能为空！";
    }
    foreach ($titles as $k2 => $v2) {
        $titles[$k2] = iconv("UTF-8", "GB2312", $v2);
    }
    $title_implode = implode("\t", $titles);

    foreach ($data as $k => $v) {
        $data[$k] = implode("\t", $v);
    }
    $data_implode = implode("\n", $data);
    $contents = $title_implode . "\n" . $data_implode;
    $file_path = "uploads/excel/";
    if (!is_dir("uploads/")) {
        mkdir("uploads/");
    }
    if (!is_dir($file_path)) {
        mkdir($file_path);
    }
    $file_name = $file_path . $filename . ".xls";

    $file_name = iconv("UTF-8", "GBK", $file_name);

    file_put_contents($file_name, $contents);
    $attachments = array($file_name);

    return $attachments;
}

function sendMail($to, $subject, $body = '', $attachment = null) { //$to 收件者 $subject主题 $body 内容  $attachment附件
    $pattern = "/^([0-9A-Za-z\\-_\\.]+)@([0-9a-z]+\\.[a-z]{2,3}(\\.[a-z]{2})?)$/i";
    if (!preg_match($pattern, $to)) {
        return "email_error";
    }
    //邮件服务器配置
    $detail = array(
        "smpt" => "smtp.qq.com",
        "account" => ".com",
        "pwd" => "",
    );

    $title = getGb2312("素材火发送excel到邮箱");
    include_once('phpmailer/class.phpmailer.php');
    $mail = new PHPMailer(); //PHPMailer对象
    $mail->CharSet = 'GB2312'; //设定邮件编码，默认ISO-8859-1，如果发中文此项必须设置，否则乱码
    $mail->Encoding = "base64";
    $mail->IsSMTP();  // 设定使用SMTP服务
    $mail->SMTPDebug = 0;                     // 关闭SMTP调试功能
    $mail->SMTPAuth = true;                  // 启用 SMTP 验证功能
    $mail->SMTPSecure = '';                 // 使用安全协议
    $mail->Host = $detail['smpt'];  // SMTP 服务器
    $mail->Port = "25";  // SMTP服务器的端口号
    $mail->Username = $detail['account'];  // SMTP服务器用户名
    $mail->Password = $detail['pwd'];  // SMTP服务器密码
    $mail->Subject = getGb2312($subject); //邮件标题
    $mail->SetFrom($detail['account'], $title);
    $mail->MsgHTML(getGb2312($body));
    $mail->AddAddress(getGb2312($to), $title);

    if (is_array($attachment)) { // 添加附件
        foreach ($attachment as $file) {
            is_file($file) && $mail->AddAttachment($file);
        }
    }
    $rs = $mail->Send() ? true : $mail->ErrorInfo;
    return $rs;
}

function getGb2312($file) {
    return iconv('UTF-8', 'GB2312', $file);
}
