<?php

include_once 'function.php';
$email  = $_POST['email'];
$titles = array("id", "时间", "名称"); //excel 列
$datas = array(
    0 => array(
        "id" => "1",
        "date" => date("Y-m-d", strtotime("-1 day")),
        "name" => "素材火"
    ),
    1 => array(
        "id" => "2",
        "date" => date("Y-m-d"),
        "name" => "分享微博送30积分"
    ),
);
$file_name = date("Y-m-d") . "素材火excel发送";
$attachments = sendExcel($file_name, $titles, $datas);
$rs = sendMail($email, "excel标题测试", "素材火内容测试，欢迎来到素材火<a href='http://www.sucaihuo.com'>http://www.sucaihuo.com</a>", $attachments);
echo $rs;
?>